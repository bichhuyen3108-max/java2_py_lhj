package exam2_1203;

public class FilePrinter implements Printable {

	@Override
	public void print(String message) {
		// TODO Auto-generated method stub
		
	}

}
