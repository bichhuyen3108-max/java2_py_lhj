package exam2_1203;

public interface Movable {

	void move(int x, int y);
}
