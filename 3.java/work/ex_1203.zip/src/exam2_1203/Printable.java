package exam2_1203;

public interface Printable {
	
	void print(String message);
	
}
