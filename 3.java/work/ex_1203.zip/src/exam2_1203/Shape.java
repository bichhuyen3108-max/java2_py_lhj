package exam2_1203;

abstract class Shape {

	abstract double area();
	
}
