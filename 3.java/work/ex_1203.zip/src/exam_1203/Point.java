package exam_1203;

public class Point {
	
	int x =0;
	int y =0;
	
	public Point() {
		
	}

	public Point(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	void printPoint() {
		System.out.println("x="+ x+", y="+y);
	}
	
	
	
	
	
}
