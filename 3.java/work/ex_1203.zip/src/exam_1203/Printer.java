package exam_1203;

public class Printer {

	void print(String message) {
		System.out.println("문자열: "+ message);
	}
	
	void print(int value) {
		System.out.println("정수:"+ value);
	}
	
	void print(double value) {
		System.out.println("실수: "+ value);
	}
	
	
	
	
	
	
	
	
	
	
}
